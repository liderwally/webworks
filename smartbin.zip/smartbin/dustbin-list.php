<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/general.css">
    <title>Document</title>
</head>

<style>
    .row{
        width: 98%;
        height: fit-content;
        border: 2px solid black;
        border-radius: 10px;
        margin: 10px;
        background-color: rgba(142, 146, 149, 0.429);
    }
    #topbar{
        display:flex ;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: flex-start;
    }
    .col{
        width: fit-content;
        height: 100%;
        /* border: 2px solid black; */
        border-radius: 10px;
        margin: 10px;
        /* background-color: rgba(142, 146, 149, 0.429); */
    }

    .card-container{
        display:flex ;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: flex-start;
        align-items: flex-start;
        padding: 10px ;
        margin: 10px;
        border-radius: 10px;
        background-color: rgba(142, 146, 149, 0.429);
        box-shadow: 2px 2px 3px black;
    }
    .card{
        width: 500px;
        height: fit-content;
        display:flex ;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: flex-start;
        align-items: flex-start;
        

    }
    .card-body{
        width: 200px;
        height: 200px;
        padding: 10px;
        

    }
    .cardlists{
        display:flex ;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: flex-start;
        align-items: flex-start;
        mix-blend-mode: multiply;
        border-radius: 10px;
    }
    .card-image{
        background-image: url('./icons/trash.svg');
        background-size: 100px 200px;
        background-repeat: no-repeat;
        background-position: 10px 10px;
        padding: 10px;
        width: 100px;
        height: 200px;
    }
    .searchbar{
        height: 40px;
        width: 600px;
        padding: 10px;
        border-radius: 15px;
        box-shadow: 2px 2px 3px black;
        /* background-color: rgba(200,200,200,0.2); */
        color:black;
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
    }
    #card-filter{
        background-image: url('./icons/search.svg');
        background-position: 550px 10px;
        background-size: 50px 50px;
        background-repeat: no-repeat;
    }
    .addBin{
        box-shadow: 2px 2px 3px black;
        width: fit-content;
        height: fit-content;
        display: flex;
        width: fit-content;
        height: fit-content;
        flex-direction: column;
        flex-wrap: nowrap;
        align-content: cen

    }
    body{
        padding-left: 25px;
        background-color: var(--body-bg-color);
        color: var(--body-color);
    }

</style>
<body>
<div class="container">
	<div class="row" id="topbar">
		<div class="col">
			<h1>Registered Dustbins</h1>
		</div>
        <div class="col">
            <input type="text" class="searchbar" id="card-filter" name="search" onchange="filter()" placeholder="Enter Location by name.....">
        </div>
		<div class="col ">
			<a href="dustbin-registration.php" class="btn addBin" ><img src='./icons/plus.svg' alt='' ></a>
		</div>

	</div>

    <div class="row cardlists">
	<?php
    include 'ghome.php';
	// query to get list of industries
	$query = "SELECT * FROM dustbin";
	$result = mysqli_query($conn, $query);

	// check if any results are found
	if (mysqli_num_rows($result) > 0) {
		// loop through each row in the result set
		while ($row = mysqli_fetch_assoc($result)) {
			// extract dustbin data from row
			$id = $row['id'];
			$name = $row['NAME'];
			$longitude = $row['longitude'];
            $latitude = $row['latitude'];

			// display dustbin data and buttons in a card
			echo "<div class='card-container' id = 'card$id'>";
                echo "<div class='card'>";
                    echo "<div class='col card-body'>";
                        echo "<div class=' ' >";
                            echo "<h5 class='card-title'>$name</h5>";
                            echo "<h6 class='card-subtitle'>latitude: $latitude longitude: $longitude</h6>";
                            echo "<a href='dustbin-dashboard.php?id=$id' class='btn btn-primary'>View</a> ";
                            echo "<a href='dustbin-editing.php?id=$id' class='btn btn-primary'>Edit</a> ";
                            echo "<a href='dustbin-delete.php?id=$id' class='btn btn-danger' onclick='confirmDelete()'>Delete</a>";
                        echo "</div>";
                    echo "</div>";

                    echo "<div class='col card-image'>";
                    echo "</div>";

                echo "</div>";

            echo "</div>";
    }
	} else {
		// display no results message
		echo "<div class='col'>";
		echo "<p>No dustbin found.</p>";
		echo "</div>";
	}

	// close database connection
	mysqli_close($conn);
?>
</div>
</div>
</body>



</html>

<script>
    var confirmDelete = ()=>{
        return confirm("Are you sure you want to delete this dustbin?");
    }
    const filter = ()=>{
        let cardNames = document.querySelectorAll(".card-title");
        let cards = document.getElementsByClassName("card-container");
        console.log(cards[0].innerText);
        console.log(cardNames.length);
        let theText = document.querySelector("#card-filter").value.toUpperCase();
        console.log(theText);
        for(i = 0; i < cardNames.length; i++){
            console.log(cardNames[i].innerText.toUpperCase());
            if( cardNames[i].innerText.toUpperCase().indexOf(theText) > -1){
                cards[i].style.display ="";
            }
            else{
                cards[i].style.display = "None";
            }
        } 
    }
    </script>