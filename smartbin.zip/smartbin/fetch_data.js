document.addEventListener('DOMContentLoaded', function() {
    fetch('fetch_data.php')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            const locations = data.map(d => ({
                lon: d.longitude,
                lat: d.latitude,
                text: `Name: ${d.NAME}<br>Level: ${d.level}<br>last Updated(Time): ${d.updated_at}`
            }));
            
            const mapData = {
                type: 'scattergeo',
                mode: 'markers',
                text: locations.map(loc => loc.text),
                lon: locations.map(loc => loc.lon),
                lat: locations.map(loc => loc.lat),
                marker: {
                    size: 20,
                    color: 'blue'
                }
            };

            const layout = {
                geo: {
                    projection: {
                        type: 'natural earth'
                    },
                    showland: true,
                    landcolor: 'rgb(217, 217, 200)',
                    subunitwidth: 1,
                    countrywidth: 1,
                    subunitcolor: 'rgb(255,255,255)',
                    countrycolor: 'rgb(255,255,255)'
                },
                margin: { t: 0, b: 0 }
            };

            Plotly.newPlot('map', [mapData], layout);
        })
        //.catch(error => console.error('Error fetching data:', error));
});