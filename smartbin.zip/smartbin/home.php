<!DOCTYPE html>
<html>
<head>
	<title>Carbon Dioxide Concentration</title>

<?php
include 'ghome.php';
?>
	<link rel="stylesheet" href="./style/general.css">
	<style>

		/* Style the top navigation bar */

		#topnav {
			height: 35px;
			width : auto;
		}

		#container{
			height: 620px;
			width:96vw;

		}
		/* Style the links inside the navigation bar */
		#topnav .tab {
		  float: left;
		  height: 80%;
		  width: 90px;
		  /* top:-10px; */
		  left: -15px;
		  color: var(--tab-color);
		  background-color: var(--tab-bg-color);
		  text-align: center;
		  /* box-shadow: 0px 0px 3px 2px var(--body-bg-color); */
		  padding: 14px 16px;
		  margin-left: 0px;
		  text-decoration: none;
		  font-size: 17px;
		  border-radius:15px;
		  transition: .425ss;
		}
		/* Change the color of links on hover */
		#topnav .tab:hover {
			background-color: var(--nav-color) ;
			color: var(--nav-bg-color);
		}
		iframe{
			width: 97%;
			height:600px;
			background-color: rgb(255, 255, 255);
			border-radius:10px;
			position: absolute;
		}
		.frameMap{
			left: 5px;
		}
		.frameList{
			left: 10px;
		}
		.frameManage{
			left: 15px;
		}
		#topnav {
		list-style-type: none;
		background-color: var(--nav-bg-color);
		color: var(--nav-color);
		/* border-top:5px solid #333; */
		}
		#topnav .tab {
		display: inline-block;
		background-color: var(--tab-bg-color);
		margin: 0 40px;
		padding: 0.625rem 2rem;
		position: relative;
		border-bottom-left-radius: 0;
		border-bottom-right-radius: 0;
		border-top-left-radius: 25px;
		border-top-right-radius: 25px;
		cursor: pointer;
		}

		#topnav .tab:after,
		#topnav .tab:before {
		content: '';
		height: 20px;
		width: 20px;
		background-color: inherit;
		position: absolute;
		bottom: 0;
		right: -20px;
		z-index: 1;
		}

		#topnav .tab:before {
		right: auto;
		left: -20px;
		}

		#topnav .tab span:after,
		#topnav .tab span:before {
		content: '';
		height: 40px;
		width: 40px;
		background-color: var(--nav-bg-color);
		position: absolute;
		top: 5px;
		right: -40px;
		z-index: 2;
		border-radius: 50%;
		}

		#topnav .tab span:before {
		right: auto;
		left: -40px;
		}
		#topnav .tab span{
			cursor: pointer;
		}
		.mainFrame{
			background-image: url("./smartbin\ theme.jpeg");
		}

</style>

</head>

<body>
	<!-- Create the top navigation bar -->
	<div class="nav" id="topnav">
	  <div class="tab" onclick="tab(0)"><span>Home</span></div>
	  <div class="tab" onclick="tab(1)"><span>Map</span></div>
	  <div class="tab" onclick="tab(2)"> <span>dustbin lists</span></div>
	  <div class="tab" onclick="tab(3)"><span>Manage</span></div>
	</div>
	<div class='nav' id="container">

	<iframe class="mainFrame" src="./gboard.php" frameborder="0"></iframe>
	<iframe class="frameMap" src="./map.php" frameborder="0"></iframe>
	<iframe class="frameList" src="./dustbin-list.php" frameborder="0"></iframe>
	<iframe class="frameManage" src="./manager.php" frameborder="0"></iframe>

	</div>
</body>
	<!-- Include the Highcharts library and the JavaScript code for the polygon line graph -->
<script src="home.js"></script>


</html>
