<?php
include 'ghome.php';
// check if the id parameter is set
if (isset($_GET['id'])) {
	// get the id parameter
	$id = $_GET['id'];

	// database connection code goes here
    include './connection.php';
	// query to delete dustbin from database
	$query = "DELETE FROM binmen WHERE id = $id";
	$result = mysqli_query($conn, $query);
	// $query = "DELETE FROM smartbin WHERE dustbin_id = $id";
	// $result = mysqli_query($conn, $query);

	// check if delete was successful
	if ($result) {
		// redirect to listing page
		header("Location: manager.php");
		exit;
	} else {
		// display error message
		echo "Error deleting dustbin. Please try again.";
	}

	// close database connection
	mysqli_close($conn);
}
?>
<script>
  window.location.href="/manager.php";
</script>