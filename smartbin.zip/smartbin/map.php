<!doctype html>
<?php 
include 'ghome.php';

$id = 0;
$timeinit;  // ('H-i-s')
$timefinal; // (H-i-s')


//other data sets
$datetimeinit;
$datetimefinal;
$starttime = 0;
$endtime = 0;

if($_GET){

    $date = $_GET["date"];
    $id = $_get["id"];
    $timeinit = $_GET["starttime"];
    $timefinal = $_GET["endtime"];
    $datetimeinit = new DateTime($date.' '.$timeinit);
    $datetimefinal = new DateTime($date.' '.$timefinal);
    $starttime  = $datetimeinit->format('H') * $datetimeinit->format('i') * $datetimeinit->format('s') ;
    $endtime =  $datetimefinal->format('H') * $datetimefinal->format('i') * $datetimefinal->format('s');

}


if($id == 0){

$bins_query = sprintf("SELECT * FROM dustbin");
$data_query = sprintf("SELECT  * FROM smartbin");
$manager_query = sprintf("SELECT  * FROM binmen");

} 
else {
    $bins_query = sprintf("SELECT DISTINCT (NAME, longitude, latitude) FROM dustbin where id =".$id);
    $data_query = sprintf("SELECT DISTINCT (dustbin_id, level, recordedTime) FROM smartbin where id=".$id);
    $manager_query = sprintf("SELECT * FROM binmen");
}

$dustBins = []; 
$dustMen  = [];
$datas = [];

// $dustBin = """
// {
//     id: 11,
//     name: "Makumbusho stand, West",
//     longitude: -73.986245,
//     latitude:  40.733991
// }
// """;


// // $dustman ="""
// // {
// //     id:01;
// //     name:"John Doe";
// //     mobile: "0756483921",
// //     dust1Id : 1,
// //     dust2Id : 2,
// //     dust3Id : 3,
// //     dust4Id : 4,
// //     dust5Id : 5
// // }
// // """;

// // $data = """
// // {
// //     "dustbin_id" : 11,
// //     "level" : 20,
// //     "time" : "2024-03-30 14:16:52"
// //     "timezone" : 3,
// // }

// // """

// // $dustBins = json_decode($dustBin, true);


if(true)
{
  $bins_query_result = mysqli_query($conn,$bins_query);
  $data_query_result = mysqli_query($conn,$data_query);
  $manager_query_result = mysqli_query($conn,$manager_query);
}



$id = array();
$level = array();
$extractedtime = array();
$timestamps = array();
$id = array();

// if ($result) { 
//     // Fetch the result as an associative array
//     $data = $result->fetch_all(MYSQLI_ASSOC);
  
//     // Access the "id" and "level" values from the array
    
//     foreach ($data as $row) {
//         $level= $row['level'];
//         $timestamps[]= $row['recordedTime']; 
//         $id = $row['id'];

//     }

//     // Create a DateTime object using the current timestamp

//     foreach($timestamps as $tim){
//       $dateTime = new DateTime($tim);
//       array_push($extractedtime, $dateTime);
//     }


//     $result->free();
// }
// else {
//   // Handle the query error
//   echo "Error executing the query: ". $mysqli->error;
// } 
// // Close the database connection
// $conn->close();


//we have two arrays of data now! 
//extractedtime: time to which the data was recorded
//level: data to display

?>

<html>
    <head>
        <!-- Recommended meta tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">

        <!-- PyScript CSS -->
        <link rel="stylesheet" href="https://pyscript.net/releases/2024.1.1/core.css">
        <!-- CSS for examples -->

        <!-- This script tag bootstraps PyScript -->
        <script type="module" src="https://pyscript.net/releases/2024.1.1/core.js"></script>
        <script defer src="https://cdn.plot.ly/plotly-2.10.1.min.js"></script>

        <!-- for splashscreen -->
        
        <title>Map plots</title>
        <link rel="icon" type="image/png" href="./icons/airplane.svg" />
    </head>
    <script>

    </script>

<style>
    body{
        width:100vw;
        height:100vh;
        background-color:var(--body-bg-color);
        overflow: hidden;
        margin: 10px;
    }
    .chart{
        background-color:#4CAF50;
        width:calc( 100% - 40px);
        height:calc( 100% - 20px);
        border-radius: 10px;
        margin: 10px;
        left:0px;
        display:block;
        padding-top:10px;
    }
    .beforemychart{
        background-color:#4CAFCB;
        width:calc(100% - 20px);
        height:calc(10% - 20px);
        border-radius: 10px;
        margin: 10px;
        left:0px;
    }
    .myChart{
        background-color:#4CAFCB;
        width:calc(100% - 20px);
        height:calc(80% - 20px);
        overflow-y: auto;
        border-radius: 10px;
        margin: 10px;
        left:0px;
    }
    .aftermychart{
        background-color:#4CAFCB;
        width:calc(100% - 20px);
        height:calc(10% - 20px);
        border-radius: 10px;
        margin: 10px;
        left:0px;
    }
    .plots{
        width:97%;
        height: 48%;
        padding: 10px;
        margin: 10px;
        border-radius: 10px;
    }
    
    

</style>


    <body>
        <div class="chart">

            <div class="beforemychart">

            </div>

            <div class="myChart">
                <section class="pyscript">
                    <div class="plots" id="map">
                        
                    </div>
                    <div class="plots" id ="charts">
                        
                    </div>
                </section>

            </div>

            <div class="aftermychart">
            
            </div>
        </div>

    </body>
<script src="fetch_data.js" ></script>
</html>
