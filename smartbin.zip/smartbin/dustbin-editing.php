<?php

$id  = 1;
$name = "";
$longitude = "";
$latitude = "";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
		// Validate the input data
		// $id = trim($_POST["id"]);
		// Get the current URL
	$currentUrl = $_SERVER['REQUEST_URI'];

	// Extract the query string from the URL
	$queryString = parse_url($currentUrl, PHP_URL_QUERY);

	// Parse the query string and retrieve the 'id' parameter
	parse_str($queryString, $params);

	// Extract the 'id' value
	// $id = $params['id'];
	echo" <script>alert($currentUrl);</script>";
	$name = trim($_POST["name"]);
	$longitude = trim($_POST["longitude"]);
	$latitude = trim($_POST["latitude"]);
	
	if (empty($name)) {
		$errors[] = "dusbin name is required";
	}
	
	if (empty($longitude)) {
		$errors[] = "dustbin longitude(longitude) is required";
	}
		
	if (empty($latitude)) {
		$errors[] = "dustbin longitude(latitude) is required";
	}
	
	// If there are no validation errors, update the data in the database
	if (empty($errors)) {
		include 'connection.php';
		}
		
		// Prepare the SQL query
		// $sql = "UPDATE dustbin SET NAME='.$name.', longitude='.$longitude.' WHERE id='$url_id'";
		$sql = "UPDATE dustbin SET NAME='$name', longitude='$longitude',latitude='$latitude' WHERE id='$id'";

		// Execute the query
		if(mysqli_query($conn, $sql)) {
			// Redirect to a success page
			header("./smartbin/dustbin-list.php");
			exit();
		} else {
			// Display an error message
			$errors[] = "Error: " . mysqli_error($conn);
		}
		
		// Close the database connection
		mysqli_close($conn);
	}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="../../ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script></head>
<body>
	<div class="container mt-4">
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<h1>Edit dustbin</h1>
				<form action="dustbin-editing.php" method="POST">
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<div class="form-group">
						<label for="name">Name</label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
					</div>
					<div class="form-group">
						<label for="longitude">Longitude</label>
						<input type="text" class="form-control" id="longitude" name="longitude" value="<?php echo $longitude; ?>">
					</div>
					<div class="form-group">
						<label for="latitude">Lalitude</label>
						<input type="text" class="form-control" id="latitude" name="latitude" value="<?php echo $latitude; ?>">
					</div>
					<button type="submit" class="btn btn-primary">Save Changes</button>
				</form>
			</div>
		</div>
	</div>


</body>

	<!-- Bootstrap JS -->
	<script src="http://localhost/CO2-conc-dashboard/code.jquery.com_jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="http://localhost/CO2-conc-dashboard/cdn.jsdelivr.net_npm_@popperjs_core@2.9.3_dist_umd_popper-base.min.js"></script>
	<script src="http://localhost/CO2-conc-dashboard/stackpath.bootstrapcdn.com_bootstrap_4.3.1_js_bootstrap.min.js"></script>
</html>