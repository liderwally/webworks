<!DOCTYPE html>

<?php
$date;  // ('Y-m-d')
$id = 00;
$timeinit;  // ('H-i-s')
$timefinal; // (H-i-s')

include 'ghome.php';
//other data sets
$datetimeinit;
$datetimefinal;
$starttime = 0;
$endtime = 0;

if($_GET){

    $date = $_GET["date"];
    $id = $_get["id"];
    $timeinit = $_GET["starttime"];
    $timefinal = $_GET["endtime"];
    $datetimeinit = new DateTime($date.' '.$timeinit);
    $datetimefinal = new DateTime($date.' '.$timefinal);
    $starttime  = $datetimeinit->format('H') * $datetimeinit->format('i') * $datetimeinit->format('s') ;
    $endtime =  $datetimefinal->format('H') * $datetimefinal->format('i') * $datetimefinal->format('s');

}

$query = sprintf("SELECT DISTINCT id,level, recordedTime FROM smartbin");

//execute query
// $result = mysqli->query($query);
if(mysqli_query($conn,$query))
{
  $result=mysqli_query($conn,$query);
}
$id = array();
$level = array();
$extractedtime = array();
$timestamps = array();
$id = array();

if ($result) { 
    // Fetch the result as an associative array
    $data = $result->fetch_all(MYSQLI_ASSOC);
  
    // Access the "id" and "level" values from the array
    
    foreach ($data as $row) {
        $level= $row['level'];
        $timestamps[]= $row['recordedTime']; 
        $id = $row['id'];

    }

    // Create a DateTime object using the current timestamp

    foreach($timestamps as $tim){
      $dateTime = new DateTime($tim);
      array_push($extractedtime, $dateTime);
    }

    $result->free();
}
else {
  // Handle the query error
  echo "Error executing the query: ". $mysqli->error;
} 
// Close the database connection
$conn->close();


//we have two arrays of data now! 
//extractedtime: time to which the data was recorded
//level: data to display

?>

<html>
  <head>
    <title>Plotly</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://pyscript.net/releases/2024.1.1/core.css" />
    <script type="module" src="https://pyscript.net/releases/2024.1.1/core.js"></script>
    <script defer src="https://cdn.plot.ly/plotly-2.10.1.min.js"></script>
    <py-env>
      - numpy
      - plotly
    </py-env>
    </head>


    <body>
      <div id="mygraph"></div>
      <script type="py" src="./map.py" config="./pymap.toml"></script>
    </body>
    
</html>