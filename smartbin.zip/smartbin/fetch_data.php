<?php
include "ghome.php";


$sql4 = "SELECT * FROM dustbin";
$result = $conn->query($sql4); 
$data = array();
if ($result->num_rows > 0) {
    $datas = $result->fetch_all(MYSQLI_ASSOC);
    foreach ($datas as $row) {
        array_push($data, $row);
    }
}

echo json_encode($data);

$conn->close();

?>