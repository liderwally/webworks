<?php
include '../connection.php';


// preparing data from gateway to an array called $logdata
$logData = array();
$logData["id"] = 0;
$logData["data"] ="0";
$logData["state"] = 2; //  0 = get-in-data, 1 = geting-out-data, 2 = loading while getting out data

// if "get" method is used
if (($_GET)){
        foreach($_GET as $comm => $comm_value){
            
            switch($comm){
                case 'data':
                    $logData["data"] =$comm_value;
                    break;
                case 'state':
                    $logData["state"] =$comm_value;
                    break;
                default:
                    $logData["id"] =$comm_value;
                    break;
            }
        }
}
// or "POST" method is used
elseif(($_POST)){
    foreach($_POST as $comm=> $comm_value){
        switch($comm){
            case 'data':
                $logData["data"] =$comm_value;
                break;
            case 'state':
                $logData["state"] =$comm_value;
                break;
            default:
                $logData["id"] =$comm_value;
                break;
        } 
    }
}



// foreach( $logData as $key => $value){
//     echo $key." : ".$value."  ";
// }



if($logData["state"] == 0){ // logging data
    $ourtime = new DateTime('now' , new DateTimeZone('Africa/Nairobi'));
    $ourtimes = $ourtime ->format('Y-m-d H:i:s');
	$sql = "INSERT INTO smartbin (dustbin_id,level,recordedTime) VALUES ($logData[id],$logData[data], '$ourtimes')";
    $sql1 = "update dustbin set level = $logData[data] where id = $logData[id]";

    $result = $conn->query($sql) ;
    if ($result === false) {
        echo 'Error: ' . mysqli_error($conn);
    }
    $result2 = $conn->query($sql1);
    if ($result2 === false) {
        echo 'Error: ' . mysqli_error($conn);
        }

}

elseif($logData["state"] ==1){ //getnumber
    $numberQuery = sprintf("select Mobile FROM BINMEN where Bin1id = $logData[id]");
    $numresult = $conn->query($numberQuery) ;
    $index = $numresult->fetch_assoc();
    if(is_array($index)){
        $value = $index['Mobile'];
    }elseif (!is_array($index)) {
        $value = $index;
    }
    echo "$value\n\r";
}

elseif($logData["state"] ==4){ //getbinmen
    $binmenDet = array();
    $query = sprintf("select * FROM BINMEN ");
    $binmenresult = $conn->query($query);
	if (mysqli_num_rows( $binmenresult ) > 0) {
		// loop through each row in the result set
		while ($row = mysqli_fetch_assoc($binmenresult)) {
			// extract dustbin data from row
			$id = $row['ID'];
			$name = $row['firstName'];
			$number = $row['Mobile'];
            $binId = $row['Bin1id'];
            $subMessg = "$name,$number,$binId";
            array_push($binmenDet, $subMessg);
        }
    $output = implode("|", $binmenDet);
    echo $output;

    }
}
elseif($logData["state"] ==2){  //logging and getnumber

//getting a number
$numberQuery = sprintf("select Mobile FROM BINMEN where Bin1id = $logData[id]");
$numresult = $conn->query($numberQuery) ;
$index = $numresult->fetch_assoc();
if(is_array($index)){
    $value = $index['Mobile'];
}elseif (!is_array($index)) {
    $value = $index;
}
echo "$value\n\r";

//logging data
$ourtime = new DateTime('now' , new DateTimeZone('Africa/Nairobi'));
$ourtimes = $ourtime ->format('Y-m-d H:i:s');
$sql = "INSERT INTO smartbin (dustbin_id,level,recordedTime) VALUES ($logData[id],$logData[data], '$ourtimes')";
$sql1 = "update dustbin set level = $logData[data] where id = $logData[id]";
$result = $conn->query($sql) ;
$result1 = $conn->query($sql1) ;
if (($result & $result1) === false) {
    echo 'Error: ' . mysqli_error($conn);
}
}



?>