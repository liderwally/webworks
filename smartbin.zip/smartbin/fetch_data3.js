async function getDustbinData() {
    const locationsResponse = await fetch('data.php');
    const locationsData = await locationsResponse.json();
  
    // Fetch latest levels using aggregation
    const levelDataResponse = await fetch('dustbin_levels_aggregated.php');
    const levelData = await levelDataResponse.json();
  
    // Combine location and level data (optimized for large datasets)
    const combinedData = locationsData.map(location => {
      const level = levelData.find(data => data.dustbin_id === location.dustbin_id)?.level;
      return { ...location, level };
    });
  
    return combinedData;
  }
  
  async function initMap() {
    const dustbinLocations = await getDustbinData();
  
    const mapData = [];
    for (const location of dustbinLocations) {
      mapData.push({
        type: 'scattermapbox',
        lon: location.longitude,
        lat: location.latitude,
        text: location.name,
        mode: 'markers',
        marker: {
          size: 12
        },
        customdata: [location.level] // Add level data to customdata
      });
    }
  
    const layout = {
      title: 'Smart Dustbin Locations (Dar es Salaam)',
      mapbox: {
        center: {
          lon: 39.282726, // Longitude of Dar es Salaam (adjust if needed)
          lat: -6.802046  // Latitude of Dar es Salaam (adjust if needed)
        },
        zoom: 10 // Medium zoom level
      }
    };
  
    const config = {
      displayModeBar: false, // Hide default hover info
      hoverinfo: 'text + customdata[0]', // Display text and level on hover
    };
  
    Plotly.newPlot('map', mapData, layout, config);
  }
  
  initMap();
  