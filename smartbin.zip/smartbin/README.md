dashboard


when passing data from php to js 
USE:



<!-- <script defer src="https://cdn.plot.ly/plotly-2.10.1.min.js"></script> -->