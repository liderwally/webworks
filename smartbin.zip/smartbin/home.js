
const tabs = document.querySelectorAll('.tab');
// console.log(tabs[1]);
const frame = document.querySelector('.mainFrame');
const listframe = document.querySelector('.frameList');
const manageframe = document.querySelector('.frameManage');
const mapframe = document.querySelector('.frameMap');
var selected_tab = tabs[0];
var root = document.querySelector(':root');
var rootStyle = getComputedStyle(root);

frame.style.left = "15px";
listframe.style.left = "-2000px";
manageframe.style.left = "-2000px";
mapframe.style.left = "-2000px";



// alert("Hi there");
function tab(index){
    switch (index) {
        case 1:
            selected_tab = tabs[1];
            selected_tab.style.backgroundColor = rootStyle.getPropertyValue('--body-bg-color');
            selected_tab.style.color = rootStyle.getPropertyValue('--color');
            tabs[0].style.backgroundColor = rootStyle.getPropertyValue('--tab-bg-color');
            tabs[0].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[2].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[2].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[3].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[3].style.color = rootStyle.getPropertyValue('--tab-color');
            frame.style.left = "-2000px";
            mapframe.style.left = "15px";
            listframe.style.left = "-2000px";
            manageframe.style.left = "-2000px";

            break;
        case 2:
            selected_tab = tabs[2];
            selected_tab.style.backgroundColor = rootStyle.getPropertyValue('--body-bg-color');
            selected_tab.style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[0].style.backgroundColor = rootStyle.getPropertyValue('--tab-bg-color');
            tabs[0].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[1].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[1].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[3].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[3].style.color = rootStyle.getPropertyValue('--tab-color');
            frame.style.left = "-2000px";
            mapframe.style.left = "-2000px";
            listframe.style.left = "15px";
            manageframe.style.left = "-2000px";
			
            break;
        case 3:
            selected_tab = tabs[3];
            selected_tab.style.backgroundColor = rootStyle.getPropertyValue('--body-bg-color');
            selected_tab.style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[0].style.backgroundColor = rootStyle.getPropertyValue('--tab-bg-color');
            tabs[0].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[1].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[1].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[2].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[2].style.color = rootStyle.getPropertyValue('--tab-color');
            frame.style.left = "-2000px";
            mapframe.style.left = "-2000px";
            listframe.style.left = "-2000px";
            manageframe.style.left ="15px";
            break;
    
        default:
            selected_tab = tabs[0];
            selected_tab.style.backgroundColor = rootStyle.getPropertyValue('--body-bg-color');
            selected_tab.style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[1].style.backgroundColor = rootStyle.getPropertyValue('--tab-bg-color');
            tabs[1].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[2].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[2].style.color = rootStyle.getPropertyValue('--tab-color');
            tabs[3].style.backgroundColor =rootStyle.getPropertyValue('--tab-bg-color');
            tabs[3].style.color = rootStyle.getPropertyValue('--tab-color');
            frame.style.left = "15px";
            mapframe.style.left = "-2000px";
            listframe.style.left = "-2000px";
            manageframe.style.left ="-2000px";
            break;
    }

}