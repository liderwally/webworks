<?php

$id  = 1;
$name = "";
$mobile = "";
$binId = "";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
		// Validate the input data
	// $id = trim($_POST["id"]);
		// Get the current URL
	$currentUrl = $_SERVER['REQUEST_URI'];

	// Extract the query string from the URL
	$queryString = parse_url($currentUrl, PHP_URL_QUERY);

	// Parse the query string and retrieve the 'id' parameter
	parse_str($queryString, $params);

	// Extract the 'id' value
	$id = $params['id'];
	echo" <script>alert($currentUrl);</script>";
	$name = trim($_POST["name"]);
	$mobile = trim($_POST["mobile"]);
	$binId = trim($_POST["binId"]);
	
	if (empty($name)) {
		$errors[] = "dusbin name is required";
	}
	
	if (empty($mobile)) {
		$errors[] = "binmen mobile(mobile) is required";
	}
		
	if (empty($binId)) {
		$errors[] = "binmen dustbin id(binId) is required";
	}
	
	// If there are no validation errors, update the data in the database
	if (empty($errors)) {
		include 'connection.php';
		}
		
		// Prepare the SQL query
		// $sql = "UPDATE binmen SET NAME='.$name.', mobile='.$mobile.' WHERE id='$url_id'";
		$sql = "UPDATE binmen SET NAME='$name', mobile='$mobile',bin1Id='$binId' WHERE id='$id'";

		// Execute the query
		if(mysqli_query($conn, $sql)) {
			// Redirect to a success page
			header("./smartbin/binmen-list.php");
			exit();
		} else {
			// Display an error message
			$errors[] = "Error: " . mysqli_error($conn);
		}
		
		// Close the database connection
		mysqli_close($conn);
	}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
    <body>
	<div class="container mt-4">
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<h1>Edit binmen</h1>
				<form action="binmen-editing.php" method="POST">
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<div class="form-group">
						<label for="name">Name</label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
					</div>
					<div class="form-group">
						<label for="mobile">mobile</label>
						<input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $mobile; ?>">
					</div>
					<div class="form-group">
						<label for="binId">binId</label>
						<input type="text" class="form-control" id="binId" name="binId" value="<?php echo $binId; ?>">
					</div>
					<button type="submit" class="btn btn-primary">Save Changes</button>
				</form>
			</div>
		</div>
	</div>


</body>
</html>