async function getDustbinData() {
    const locationsResponse = await fetch('fetch_data.php');
    const locationsData = await locationsResponse.json();
  
    const dustbinDataResponse = await fetch('dustbin_levels.php');
    const dustbinData = await dustbinDataResponse.json();
  
    // Combine location and level data
    const combinedData = locationsData.map(location => {
      const level = dustbinData.find(data => data.dustbin_id === location.dustbin_id)?.level;
      return { ...location, level };
    });
  
    return combinedData;
  }
  
  async function initMap() {
    const dustbinLocations = await getDustbinData();
  
    const mapData = [];
    for (const location of dustbinLocations) {
      mapData.push({
        type: 'scattermapbox',
        lon: location.longitude,
        lat: location.latitude,
        text: location.name,
        mode: 'markers',
        marker: {
          size: 12
        },
        customdata: [location.level] // Add level data to customdata
      });
    }
  
    const layout = {
      title: 'Smart Dustbin Locations (Dar es Salaam)',
      mapbox: {
        center: {
          lon: 39.282726, // Longitude of Dar es Salaam (adjust if needed)
          lat: -6.802046  // Latitude of Dar es Salaam (adjust if needed)
        },
        zoom: 20 // Medium zoom level
      }
    };
  
    const config = {
      displayModeBar: false, // Hide default hover info
      hoverinfo: 'text+customdata[0]', // Display text and level on hover
    };
  
    Plotly.newPlot('map', mapData, layout, config);
  }
  
  initMap();