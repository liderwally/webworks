<?php
include 'connection.php';
$uid = 1;

?>