<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// Validate the input data
	$name = trim($_POST["name"]);
	$mobile = trim($_POST["mobile"]);
    $email = trim($_POST["email"]);
    $binid = trim($_POST["binid"]);
	
	if (empty($name)) {
		$errors[] = "dustmen name is required";
	}
	
	if (empty($mobile)) {
		$errors[] = "dustmen mobile is required";
	}

    if (empty($email)) {
		$errors[] = "dustmen email is required";
	}
    if (empty($binid)) {

		$errors[] = "you have to assign this binmen a dustbin id";
	}
	// If there are no validation errors, insert the data into the database
	if (empty($errors)) {
		
		include './connection.php';
		$result = mysqli_query($conn, "select max(ID) from binmen");
        $row = $result->fetch_assoc();
        $index = array_pop($row);
		// Prepare the SQL query
		$sql = "INSERT INTO binmen (ID,firstName, Mobile, Email, Bin1id) VALUES ($index +1, '$name', '$mobile' ,'$email',$binid)";
		
		// Execute the query
		if (mysqli_query($conn, $sql)) {
			// Redirect to a success page
			header("Location: manager.php");
			exit();
		} else {
			// Display an error message
			$errors[] = "Error: " . mysqli_error($conn);
		}
		
		// Close the database connection
		mysqli_close($conn);
	}
}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>DustMen Registration Form</title>
	<style>
		body {
			font-family: Arial, sans-serif;
		}
		h1 {
			font-size: 32px;
			margin-top: 50px;
			margin-bottom: 20px;
			text-align: center;
		}
		form {
			margin: auto;
			width: 50%;
		}
		label {
			display: block;
			font-size: 20px;
			margin-top: 20px;
		}
		input[type="text"], select {
			font-size: 16px;
			padding: 10px;
			width: 100%;
		}
		input[type="submit"] {
			background-color: #334294 ;
			border: none;
			color: white;
			cursor: pointer;
			font-size: 16px;
			margin-top: 20px;
			padding: 10px;
			width: 100%;
		}
		input[type="submit"]:hover {
			background-color: #45a049 ;
		}
	</style>
</head>
<body>
	<h1>DustMen Registration Form</h1>
	<form method="post" action="binmen-add.php">
		<label for="name">Name</label>
		<input type="text" id="name" name="name" required>
		<label for="mobile">Mobile</label>
		<input type="text" id="mobile" name="mobile" required>
        <label for="email">email</label>
		<input type="text" id="email" name="email" required>
        <label for="binid">Bin Id</label>
		<input type="text" id="binid" name="binid" >
		<input type="submit"  value="Register dustmen">
	</form>
</body>
<Script>
    alert('<?php echo $errors[0];?>');
</Script>
</html>