<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// Validate the input data
	$name = trim($_POST["name"]);
	$longitude = trim($_POST["longitude"]);
    $latitude = trim($_POST["latitude"]);
	
	if (empty($name)) {
		$errors[] = "dustbin name is required";
	}
	
	if (empty($longitude)) {
		$errors[] = "dustbin longitude is required";
	}

    if (empty($latitude)) {
		$errors[] = "dustbin latitude is required";
	}
	
	// If there are no validation errors, insert the data into the database
	if (empty($errors)) {
		
		include './connection.php';
		
		// Prepare the SQL query
		$sql = "INSERT INTO dustbin (NAME, longitude, latitude) VALUES ('$name', '$longitude' ,'$latitude')";
		
		// Execute the query
		if (mysqli_query($conn, $sql)) {
			// Redirect to a success page
			header("Location: dustbin-list.php");
			exit();
		} else {
			// Display an error message
			$errors[] = "Error: " . mysqli_error($conn);
		}
		
		// Close the database connection
		mysqli_close($conn);
	}
}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>dustbin Registration Form</title>
	<style>
		body {
			font-family: Arial, sans-serif;
		}
		h1 {
			font-size: 32px;
			margin-top: 50px;
			margin-bottom: 20px;
			text-align: center;
		}
		form {
			margin: auto;
			width: 50%;
		}
		label {
			display: block;
			font-size: 20px;
			margin-top: 20px;
		}
		input[type="text"], select {
			font-size: 16px;
			padding: 10px;
			width: 100%;
		}
		input[type="submit"] {
			background-color: #334294;
			border: none;
			color: white;
			cursor: pointer;
			font-size: 16px;
			margin-top: 20px;
			padding: 10px;
			width: 100%;
		}
		input[type="submit"]:hover {
			background-color: #45a049;
		}
	</style>
</head>
<body>
	<h1>dustbin Registration Form</h1>
	<form method="post" action="dustbin-registration.php">
		<label for="name">dustbin Name</label>
		<input type="text" id="name" name="name" required>
		<label for="longitude">Longitude</label>
		<input type="text" id="longitude" name="longitude" required>
        <label for="latitude">Latitude</label>
		<input type="text" id="latitude" name="latitude" required>
		<input type="submit"  value="Register dustbin">
	</form>
</body>
</html>
