<!DOCTYPE html>
<html lang="en">
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body{
  background-image: url("./smartbin\ theme.jpeg");
  background-size: contain;
  background-repeat: repeat-y;
}
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}
</style>
<body>

<!-- Navbar -->


<!-- Header -->
<header class="w3-container w3-blue w3-center w3-opacity w3-text-white" style="padding:128px 16px">
  <h1 class="w3-margin w3-jumbo">SMARTBIN SYSTEM</h1>
  <h4>"Smart Waste, Clean Future"</h4>
</header>

<!-- First Grid -->
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class=" w3-twothird">
      <h1 class="w3-container w3-red  w3-twothird">Vision</h1>
      <!-- <h5 class="w3-padding-64">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</h5> -->

      <p class="w3-row-padding w3-padding-64 w3-container w3-text-grey w3-red w3-padding-32">
        "To revolutionize waste management through intelligent technology, 
        fostering a cleaner, more efficient, and sustainable urban environment."
      </p>
    </div>

  </div>
</div>

<!-- Second Grid -->
<div class="w3-row-padding w3-light-grey w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-third w3-center">
      <i class="fa fa-coffee w3-padding-64 w3-text-red w3-margin-right"></i>
    </div>

    <div class="w3-twothird">
      <h1> 

      </h1>
      <h5 class="w3-padding-32">Why us?, Why joining with us?</h5>

      <p class="w3-text-grey">
        Imagine a city where waste management is no longer a hassle, but a seamless, efficient process.
        Introducing SmartBin, an innovative smart wastebin that monitors fill levels in real time, sends data wirelessly to a centralized system, and 
        communicates through the LoRa network. Our technology optimizes waste collection routes, reduces operational costs, and significantly cuts down on carbon emissions. 
        
        By accepting SmartBin in your city, our city, you're not just accepting a product, but a cleaner, more sustainable future for urban environments. 
        Join us in transforming waste management and revolutionizing urban living.
      </p>
    </div>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h3 class="w3-margin w3-xlarge">Made with love for UDSM</h3>
    <p>
      Designed to address the inefficiencies and challenges associated with traditional waste collection methods
    </p>
</div>

<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity">  

</footer>

<script>
// Used to toggle the menu on small screens when clicking on the menu button

</script>

</body>

<!-- Mirrored from www.w3schools.com/w3css/tryit.asp?filename=tryw3css_templates_start_page&stacked=h by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Jan 2020 01:41:36 GMT -->
</html>