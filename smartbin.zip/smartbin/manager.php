<?php
include 'ghome.php';
//prerequisites for a single board view with respect to provided time
$date;  // ('Y-m-d')
$id = 00;
$timeinit;  // ('H-i-s')
$timefinal; // (H-i-s')


//other data sets
$datetimeinit;
$datetimefinal;
$starttime = 0;
$endtime = 0;

if($_GET){

    $date = $_GET["date"];
    $id = $_get["id"];
    $timeinit = $_GET["starttime"];
    $timefinal = $_GET["endtime"];
    $datetimeinit = new DateTime($date.' '.$timeinit);
    $datetimefinal = new DateTime($date.' '.$timefinal);
    $starttime  = $datetimeinit->format('H') * $datetimeinit->format('i') * $datetimeinit->format('s') ;
    $endtime =  $datetimefinal->format('H') * $datetimefinal->format('i') * $datetimefinal->format('s');

}

$menquery = sprintf("SELECT * FROM binmen");
$binquery = sprintf("SELECT * FROM dustbin");


//execute query
$menresult = $conn->query($menquery);
$binresult = $conn->query($binquery);
$menId = array();
$menNames = array();
$menMobile = array();
$level = array();
$bin1Id = array();
$bin2Id = array();
$bin3Id = array();
$bin4Id = array();
$bin5Id = array();

if ($menresult) { 
    // Fetch the result as an associative array
    $mendata = $menresult->fetch_all(MYSQLI_ASSOC);
  
    // Access the "id" and "level" values from the array
    foreach ($mendata as $row) {
        array_push($menId, $row['ID'] );
        array_push($menNames ,$row["firstName"] );
        array_push($menMobile , $row['Mobile'] );
        array_push($bin1Id , $row['Bin1id'] );
        array_push($bin2Id , $row['Bin2id'] );
        array_push($bin3Id , $row['Bin3id'] );
        array_push($bin4Id , $row['Bin4id'] );
        array_push($bin5Id , $row['Bin5id'] );

    }

    $menresult->free();
}
else {
  // Handle the query error
  echo "Error executing the query: ". $conn->error;
} 

$binId = array();
$binName = array();

if ($binresult) { 
    // Fetch the result as an associative array
    $bindata = $binresult->fetch_all(MYSQLI_ASSOC);
  
    // Access the "id" and "level" values from the array
    foreach ($bindata as $row) {
        array_push($binId, $row['id']);
        array_push($binName, $row['NAME']);
    }


    $binresult->free();
}
else {
  // Handle the query error
  echo "Error executing the query: ". $conn->error;
} 




// Close the database connection
$conn->close();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="./style/general.css">
    <title>Document</title>
</head>

<style>

body{
    background-color: var(--body-bg-color);
}
/* Style the top navigation bar */
.nav {
  overflow: hidden;
  background-color:  var(--nav-bg-color);
  color: var(--nav-color);
  border-radius:10px;
  padding:10px ;
  margin: 10px ;
}
#topnav {
    height: 35px;

    width : auto;


}

.container{
    height: 87vh;
    width:auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-items: center;

}
/* Style the links inside the navigation bar */
#topnav .tab {
  float: left;
  height: 100%;
  width: 90px;
  top:-10px;
  color: var(--tab-color);
  background-color: var(--tab-bg-color);
  text-align: center;
  box-shadow: 0px 0px 3px 2px var(--body-bg-color);
  padding: 14px 16px;
  margin-left: 2px;
  text-decoration: none;
  font-size: 17px;
  border-radius:15px;
  transition: .825ss;
}
/* Change the color of links on hover */
#topnav .tab:hover {
  background-color: var(--tab-color) ;
  color: var(--tab-bg-color);
}
.mainFrame{
    width: 100%;
    height:100%;
    background-color: #fff0;
    border-radius:10px;
}
.addBin{
        box-shadow: 2px 2px 3px black;
        width: fit-content;
        height: fit-content;
        display: flex;
        width: fit-content;
        height: fit-content;
        flex-direction: column;
        flex-wrap: nowrap;
        align-content: cen

    }
</style>

<body>
    <div class="chart">
        <div class="beforemychart"></div>
        <div class="myChart">
        <div class="container">
  <h2>Basic Table</h2>
  <p>The table  to manage the supervision of men and dustbins 

  <div class = 'row-sep'></div>        
  <table class="table manager">
    <thead>
      <tr>
        <th>No.</th>
        <th>Name</th>
        <th>Mobile</th>
        <th>Bin Num 1</th>

      </tr>
    </thead>
    <tbody>
<?php
 for($i = 0;$i<count($menId );$i++ ){
    echo "<tr>";
    echo "<td>".$i."</td>";
    echo "<td>".array_pop($menNames)."</td>";
    echo "<td>".array_pop($menMobile)."</td>";
    echo "<td>".array_pop($bin1Id)."</td>";
    echo "<td><a href='binmen-edit.php?id=$i' class='btn btn-primary'>Edit</a> </td>";
    echo "<td><a href='binmen-delete.php?id=$i' class='btn btn-primary'>REMOVE</a> </td>";
    
    echo "</tr>";
    
 }

?>
    </tbody>
  </table>
  <div class = 'row-sep'></div>
  <div class="col ">
			<a href="binmen-add.php" class="btn addBin" ><img src='./icons/plus.svg' alt='' ></a>
      <p>add dustmen</p>
	</div>
</div>



        </div>
        <div class="aftermychart"></div>
    </div>
</body>
</html>
<script>


</script>